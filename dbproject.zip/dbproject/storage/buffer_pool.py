"""页缓存 (Buffer Pool)。
采用写穿透 (write-through) 策略：写操作立即持久化到磁盘并同时更新缓存，
从而保证任意时刻崩溃/重启都不会丢失数据，同时仍然为读操作提供缓存加速。
支持 LRU（最近最少使用）与 FIFO（先进先出）两种页替换策略，
并统计缓存命中率、记录替换日志。
"""
from collections import OrderedDict


class BufferPool:
    def __init__(self, disk_manager, capacity=64, policy="LRU"):
        self.disk_manager = disk_manager
        self.capacity = capacity
        self.policy = policy.upper()
        self.cache = OrderedDict()  # page_id -> bytes(4096)
        self.hits = 0
        self.misses = 0
        self.log = []

    def get_page(self, page_id) -> bytearray:
        if page_id in self.cache:
            self.hits += 1
            if self.policy == "LRU":
                self.cache.move_to_end(page_id)
            return bytearray(self.cache[page_id])
        self.misses += 1
        data = self.disk_manager.read_page(page_id)
        self._insert(page_id, data)
        return bytearray(data)

    def write_page(self, page_id, data: bytes):
        self.disk_manager.write_page(page_id, bytes(data))
        if page_id in self.cache:
            self.cache[page_id] = bytes(data)
            if self.policy == "LRU":
                self.cache.move_to_end(page_id)
        else:
            self._insert(page_id, bytes(data))

    def flush_page(self, page_id):
        if page_id in self.cache:
            self.disk_manager.write_page(page_id, self.cache[page_id])

    def flush_all(self):
        for pid, data in self.cache.items():
            self.disk_manager.write_page(pid, data)

    def _insert(self, page_id, data):
        if len(self.cache) >= self.capacity:
            evict_id, _ = self.cache.popitem(last=False)
            self.log.append(f"[{self.policy}] 缓存已满，淘汰页 {evict_id}，装入页 {page_id}")
        self.cache[page_id] = bytes(data)

    def stats(self):
        total = self.hits + self.misses
        rate = (self.hits / total * 100) if total else 0.0
        return {"hits": self.hits, "misses": self.misses, "hit_rate": f"{rate:.2f}%"}
