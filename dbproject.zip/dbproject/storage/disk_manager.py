"""页式存储系统 (Disk Manager)
- 页大小固定为 4KB，页号从 0 开始，全局唯一。
- 页 0 为保留的全局头页 (Header Page)，记录：
    总页数 / 空闲页链表 (供页释放后重用) / 系统目录(pg_catalog)当前占用的页号列表。
- 对外提供 allocate_page / free_page / read_page / write_page 四个基本接口。
"""
import os
import struct

PAGE_SIZE = 4096
HEADER_PAGE_ID = 0
FREE_LIST_SLOTS = 200  # 头页中为空闲页链表预留的槽位数


class DiskManager:
    def __init__(self, db_file: str):
        self.db_file = db_file
        is_new = not os.path.exists(db_file)
        self.fp = open(db_file, "w+b" if is_new else "r+b")
        if is_new:
            self.total_pages = 1  # 页 0 是头页
            self.free_list = []
            self.catalog_pages = []
            self._grow_file_to(1)
            self._write_header()
        else:
            self._read_header()

    # ---------------- 头页读写 ----------------
    def _write_header(self):
        buf = bytearray(PAGE_SIZE)
        struct.pack_into(">I", buf, 0, self.total_pages)
        struct.pack_into(">I", buf, 4, len(self.free_list))
        off = 8
        for pid in self.free_list:
            struct.pack_into(">I", buf, off, pid)
            off += 4
        cat_count_off = 8 + 4 * FREE_LIST_SLOTS
        struct.pack_into(">I", buf, cat_count_off, len(self.catalog_pages))
        off = cat_count_off + 4
        for pid in self.catalog_pages:
            struct.pack_into(">I", buf, off, pid)
            off += 4
        self._raw_write(HEADER_PAGE_ID, bytes(buf))

    def _read_header(self):
        buf = self._raw_read(HEADER_PAGE_ID)
        self.total_pages = struct.unpack_from(">I", buf, 0)[0]
        free_count = struct.unpack_from(">I", buf, 4)[0]
        off = 8
        self.free_list = []
        for _ in range(free_count):
            self.free_list.append(struct.unpack_from(">I", buf, off)[0])
            off += 4
        cat_count_off = 8 + 4 * FREE_LIST_SLOTS
        cat_count = struct.unpack_from(">I", buf, cat_count_off)[0]
        off = cat_count_off + 4
        self.catalog_pages = []
        for _ in range(cat_count):
            self.catalog_pages.append(struct.unpack_from(">I", buf, off)[0])
            off += 4

    def set_catalog_pages(self, pages):
        self.catalog_pages = list(pages)
        self._write_header()

    def get_catalog_pages(self):
        return list(self.catalog_pages)

    # ---------------- 页分配与释放 ----------------
    def allocate_page(self) -> int:
        if self.free_list:
            pid = self.free_list.pop()
        else:
            pid = self.total_pages
            self.total_pages += 1
            self._grow_file_to(self.total_pages)
        self._write_header()
        self._raw_write(pid, bytes(PAGE_SIZE))
        return pid

    def free_page(self, page_id: int):
        self.free_list.append(page_id)
        self._write_header()

    # ---------------- 对外读写接口 ----------------
    def read_page(self, page_id: int) -> bytes:
        return self._raw_read(page_id)

    def write_page(self, page_id: int, data: bytes):
        assert len(data) == PAGE_SIZE, "写入数据必须为一个完整页(4096字节)"
        self._raw_write(page_id, data)

    # ---------------- 底层文件 IO ----------------
    def _grow_file_to(self, n_pages):
        self.fp.seek(n_pages * PAGE_SIZE - 1)
        self.fp.write(b"\0")
        self.fp.flush()

    def _raw_read(self, page_id):
        self.fp.seek(page_id * PAGE_SIZE)
        data = self.fp.read(PAGE_SIZE)
        if len(data) < PAGE_SIZE:
            data = data + b"\0" * (PAGE_SIZE - len(data))
        return data

    def _raw_write(self, page_id, data):
        self.fp.seek(page_id * PAGE_SIZE)
        self.fp.write(data)
        self.fp.flush()

    def close(self):
        self._write_header()
        self.fp.close()
